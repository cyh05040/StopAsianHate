
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'cyh05040',
  applicationName: 'stopasianhate',
  appUid: 'FsrJCzvHW0MdwT7pxK',
  orgUid: 'e84800a2-7949-4ca9-9896-2b55b4a7f20b',
  deploymentUid: 'ba72695b-f2f9-47e3-9265-94e8051eb7fc',
  serviceName: 'my-app-serverless',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'my-app-serverless-dev-incident', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.incident, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}